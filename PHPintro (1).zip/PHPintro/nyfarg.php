<?php
echo '
<html>
<head>
  <title>F�rgv�xlare</title>
</head>
<body bgcolor = "'.$_POST['bgfarg'].'">
<form action="nyfarg.php" method="post">
  Hejsan, vilken f�rg vill du ha p� sidan? 
  <select name="bgfarg">
    <option value="white">vit</option>
    <option value="blue">bl�</option>
    <option value="green">gr�n</option>
    <option value="pink">sk�r</option>
  </select>
  <input type="submit" value="Ny f�rg nu!">
</form>
</body>
</html>';
?>